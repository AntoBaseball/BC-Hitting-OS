-- BC Hitting OS: proposed PostgreSQL 15+ schema (v0.1)
-- Data model for a future authenticated production service. It is NOT the local browser prototype's datastore.
-- Uses uuid, timestamptz, explicit provenance, typed metrics and audit history.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  auth_subject text NOT NULL UNIQUE, -- OIDC/SAML subject; SSO is owned by the university
  display_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin','coach','analyst','player','viewer')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE athletes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  display_name text NOT NULL,
  bats text CHECK (bats IN ('L','R','S')),
  throws text CHECK (throws IN ('L','R')),
  jersey_number text,
  class_year text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(id,organization_id)
);
CREATE INDEX athletes_org_idx ON athletes(organization_id,active);
CREATE TABLE source_systems (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  code text NOT NULL CHECK (code IN ('trackman','blast','hittrax','motion_capture','force_plate','video','manual','other')),
  label text NOT NULL,
  adapter_version text,
  configuration jsonb NOT NULL DEFAULT '{}', -- NEVER store API secrets here
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(organization_id,code,label)
);
CREATE TABLE athlete_external_ids (
  athlete_id uuid NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  source_system_id uuid NOT NULL REFERENCES source_systems(id),
  external_athlete_id text NOT NULL,
  verified_at timestamptz,
  PRIMARY KEY (athlete_id,source_system_id),
  UNIQUE(source_system_id,external_athlete_id)
);
CREATE TABLE devices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  source_system_id uuid REFERENCES source_systems(id),
  serial_number text,
  device_name text NOT NULL,
  firmware_version text,
  calibration_at timestamptz,
  active boolean NOT NULL DEFAULT true
);
CREATE TABLE ingest_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_system_id uuid NOT NULL REFERENCES source_systems(id),
  original_file_name text,
  checksum_sha256 text,
  source_uri text,
  status text NOT NULL CHECK (status IN ('queued','validating','quarantined','complete','failed')),
  received_rows integer NOT NULL DEFAULT 0,
  accepted_rows integer NOT NULL DEFAULT 0,
  rejected_rows integer NOT NULL DEFAULT 0,
  validation_messages jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);
CREATE TABLE training_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  started_at timestamptz NOT NULL,
  ended_at timestamptz,
  session_type text NOT NULL CHECK (session_type IN ('tee','front_toss','machine_blocked','machine_variable','live_bp','game','assessment','other')),
  location text,
  assigned_group text,
  coach_user_id uuid REFERENCES app_users(id),
  training_goal text,
  metadata jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX session_by_org_time ON training_sessions(organization_id,started_at DESC);
CREATE TABLE pitch_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  athlete_id uuid NOT NULL REFERENCES athletes(id),
  training_session_id uuid REFERENCES training_sessions(id),
  source_system_id uuid NOT NULL REFERENCES source_systems(id),
  device_id uuid REFERENCES devices(id),
  ingest_job_id uuid REFERENCES ingest_jobs(id),
  external_event_id text,
  occurred_at timestamptz NOT NULL,
  collection_context text NOT NULL CHECK (collection_context IN ('tee','front_toss','machine_blocked','machine_variable','live_bp','game','assessment','other','unknown')),
  pitch_type text,
  pitch_velo_mph numeric(5,2),
  plate_x_ft numeric(6,3),
  plate_z_ft numeric(6,3),
  zone_class text CHECK (zone_class IN ('damage','strike','ball','unknown')),
  swing_decision text CHECK (swing_decision IN ('swing','take','unknown')),
  contact boolean,
  exit_velo_mph numeric(5,2),
  launch_angle_deg numeric(6,2),
  spray_angle_deg numeric(6,2),
  carry_ft numeric(7,2),
  bat_speed_mph numeric(5,2),
  attack_angle_deg numeric(6,2),
  vertical_bat_angle_deg numeric(6,2),
  raw_payload jsonb, -- access-controlled; alternatively immutable object storage pointer
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (pitch_velo_mph IS NULL OR pitch_velo_mph BETWEEN 0 AND 125),
  CHECK (exit_velo_mph IS NULL OR exit_velo_mph BETWEEN 0 AND 130),
  CHECK (bat_speed_mph IS NULL OR bat_speed_mph BETWEEN 0 AND 130),
  CHECK (carry_ft IS NULL OR carry_ft BETWEEN 0 AND 650)
);
CREATE UNIQUE INDEX pitch_source_dedupe ON pitch_events(source_system_id,external_event_id) WHERE external_event_id IS NOT NULL;
CREATE INDEX pitch_athlete_time ON pitch_events(athlete_id,occurred_at DESC);
CREATE INDEX pitch_session_time ON pitch_events(training_session_id,occurred_at);
CREATE INDEX pitch_source_time ON pitch_events(source_system_id,occurred_at DESC);
-- Maintain provenance of metrics from devices with distinct definitions/versions.
CREATE TABLE measurement_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_system_id uuid NOT NULL REFERENCES source_systems(id),
  metric_key text NOT NULL,
  description text,
  unit text NOT NULL,
  definition_version text NOT NULL,
  UNIQUE (source_system_id,metric_key,definition_version)
);
CREATE TABLE event_measurements (
  event_id uuid NOT NULL REFERENCES pitch_events(id) ON DELETE CASCADE,
  definition_id uuid NOT NULL REFERENCES measurement_definitions(id),
  measured_value numeric(14,5),
  quality_status text NOT NULL DEFAULT 'unverified' CHECK (quality_status IN ('verified','unverified','suspect','rejected')),
  PRIMARY KEY (event_id,definition_id)
);
CREATE TABLE video_assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  storage_uri text NOT NULL,
  capture_started_at timestamptz,
  camera_view text,
  frame_rate numeric(7,2),
  timing_offset_ms integer,
  privacy_class text NOT NULL DEFAULT 'athlete_private',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE event_videos (
  event_id uuid NOT NULL REFERENCES pitch_events(id) ON DELETE CASCADE,
  video_id uuid NOT NULL REFERENCES video_assets(id) ON DELETE CASCADE,
  clip_in_ms integer,
  clip_out_ms integer,
  PRIMARY KEY(event_id,video_id)
);
CREATE TABLE player_development_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  athlete_id uuid NOT NULL REFERENCES athletes(id),
  created_by uuid REFERENCES app_users(id),
  primary_focus text NOT NULL,
  secondary_focus text,
  hypothesis text,
  baseline_definitions jsonb NOT NULL DEFAULT '{}',
  success_criteria jsonb NOT NULL DEFAULT '{}',
  starts_on date NOT NULL,
  ends_on date,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX devplan_player_current ON player_development_plans(athlete_id,active,starts_on DESC);
CREATE TABLE drills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  label text NOT NULL,
  skill_category text NOT NULL,
  instructions text,
  default_rules jsonb NOT NULL DEFAULT '{}'
);
CREATE TABLE training_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid REFERENCES player_development_plans(id),
  athlete_id uuid NOT NULL REFERENCES athletes(id),
  drill_id uuid REFERENCES drills(id),
  training_session_id uuid REFERENCES training_sessions(id),
  scheduled_for timestamptz NOT NULL,
  target_rep_count integer,
  context text,
  coach_instructions text,
  completion_status text NOT NULL DEFAULT 'planned' CHECK (completion_status IN ('planned','completed','missed','cancelled')),
  actual_rep_count integer,
  outcome_notes text
);
CREATE TABLE game_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id),
  game_code text NOT NULL,
  display_name text NOT NULL,
  rules_version integer NOT NULL,
  rules_json jsonb NOT NULL,
  active boolean NOT NULL DEFAULT true,
  UNIQUE(organization_id,game_code,rules_version)
);
CREATE TABLE game_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_definition_id uuid NOT NULL REFERENCES game_definitions(id),
  athlete_id uuid NOT NULL REFERENCES athletes(id),
  training_session_id uuid REFERENCES training_sessions(id),
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  rules_snapshot jsonb NOT NULL,
  scoring_mode text NOT NULL DEFAULT 'coach_manual' CHECK (scoring_mode IN ('coach_manual','sensor_assisted','verified_sensor')),
  operator_user_id uuid REFERENCES app_users(id)
);
CREATE TABLE game_reps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_session_id uuid NOT NULL REFERENCES game_sessions(id) ON DELETE CASCADE,
  pitch_event_id uuid REFERENCES pitch_events(id),
  rep_sequence integer NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  inputs jsonb NOT NULL,
  computed_points integer NOT NULL,
  adjudicated_by uuid REFERENCES app_users(id),
  UNIQUE(game_session_id,rep_sequence)
);
CREATE TABLE assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  athlete_id uuid NOT NULL REFERENCES athletes(id),
  assessment_type text NOT NULL,
  performed_at timestamptz NOT NULL,
  protocol_version text NOT NULL,
  results jsonb NOT NULL,
  reviewed_by uuid REFERENCES app_users(id),
  notes text
);
CREATE TABLE audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations(id),
  actor_user_id uuid REFERENCES app_users(id),
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX audit_org_time ON audit_log(organization_id,occurred_at DESC);

-- PRODUCTION IMPLEMENTATION NOTES:
-- 1. Add tenant-scoped row-level security + role-granular policies at app/backend layer.
--    All joins must verify athlete/session/source organization_id agreement.
-- 2. Player users may read only authorized portions of their own athlete record.
--    Biometric and medical data should live in separately permissioned stores.
-- 3. Keep vendor credentials in an encrypted secrets manager, never the database JSON.
-- 4. Store video in private object storage with expiring signed access URLs.
-- 5. Production ingestion must handle upstream identifiers, replay-safe idempotency,
--    identity resolution, units, validity, provenance, and webhook retries.
-- 6. Use event_measurements for vendor/version-specific metrics; avoid comparing
--    differently defined metrics as though equivalent.
-- 7. Enforce game scoring at server side with versioned rules, not a browser input.
