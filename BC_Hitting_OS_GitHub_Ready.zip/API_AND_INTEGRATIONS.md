# BC Hitting OS — Production API and integration contract (proposed)

This file describes the **future production platform**. It does not claim that the accompanying interactive browser prototype connects to vendors.

## Technology choices

- Web UI: Next.js/TypeScript, coach-first responsive browser experience; iPad support for cage scoring.
- Server API: Python FastAPI (or a typed TypeScript backend); PostgreSQL with migrations.
- Ingestion: asynchronous durable job queue + source adapters + S3-compatible encrypted object storage for raw files and videos.
- Identity: university-approved SSO (OIDC or SAML), five scoped roles, organization-level authorization and audit history.
- Analytics: SQL materialized summaries first; add documented model registry and validation for advanced metrics.
- Hosting: university-approved infrastructure with secure backups, role-based access, encryption, logging and incident response.

## Core REST API v1

| Method and path | Description | Required behavior |
|---|---|---|
| `GET /api/v1/athletes?active=true` | Roster / athlete identifiers | Organization scoped, paginated |
| `POST /api/v1/athletes` | Create a player | Reject duplicates or require merge review |
| `GET /api/v1/athletes/{id}` | Player profile | Permissions and limited sensitive fields |
| `PATCH /api/v1/athletes/{id}` | Edit player focus/details | Versioned, audited |
| `GET /api/v1/athletes/{id}/metrics?from=&to=&context=&source=` | Stats and trends | Return sample size, units, measurement definitions, provenance |
| `GET /api/v1/athletes/{id}/events` | Pitch/swing timeline | Cursor paginated; video link only if authorized |
| `GET /api/v1/assignments?date=&group=` | Training board | Filterable by group and coach |
| `POST /api/v1/assignments` | Add a training prescription | Store success metric and session context |
| `PATCH /api/v1/assignments/{id}` | Mark completed, add outcome | Audit change |
| `GET /api/v1/games` | Catalog of scoring games | Versioned rules |
| `POST /api/v1/game-sessions` | Start competition | Snapshots scoring rules and thresholds |
| `POST /api/v1/game-sessions/{id}/reps` | Log a rep | Compute points server-side and attach measured event if available |
| `POST /api/v1/game-sessions/{id}/finish` | Complete session | Recompute and lock official score |
| `POST /api/v1/imports` | Upload data export | Return `job_id`, validate asynchronously |
| `GET /api/v1/imports/{job_id}` | Upload status | Counts, errors, mapping review |
| `POST /api/v1/webhooks/trackman` | Vendor event receiver | Authentication / validation / replay-safe enqueue |
| `GET /api/v1/reports/player/{id}` | Coach report | Source-context filters and latest intervention notes |

### Example measurement response

```json
{
  "athlete_id": "<uuid>",
  "metric": "exit_velocity_p90",
  "value": 101.7,
  "unit": "mph",
  "n_valid": 92,
  "n_excluded": 4,
  "context": "machine_variable",
  "source": "trackman",
  "measurement_version": "vendor-reported-v1",
  "period": {"from": "2026-09-01", "to": "2026-10-15"},
  "quality": "reviewed",
  "is_example": true
}
```

The values above are illustrative, not real Boston College measurements.

## Integration source-of-truth / due diligence

### TrackMan

- TrackMan documentation verifies a **Data API** for ball-tracking measurements/media, including game and practice sessions, subject to Data API agreement, credentials and applicable add-on.
- The Portable B1 play-by-play feed documents near-real-time ball tracking via webhooks, **but does not include player-name tagging metadata** in its payload; athlete/session reconciliation is therefore required. Missed deliveries may need a later post-session reconciliation.
- **Initial plan:** obtain authorization; build post-session importer using official vendor IDs; then implement validated event feed and daily reconciliation.
- References: https://support.trackmanbaseball.com/hc/en-us/articles/5089419125403-Data-Data-API-Introduction and https://support.trackmanbaseball.com/hc/en-us/articles/5089771759003-B1-App-Trackman-Data-Feeds-Live-Play-by-Play

### Blast Motion

- Blast documents team report exports to CSV/Excel. Its key metrics include bat speed, attack angle, and vertical bat angle.
- **Initial plan:** authorized team CSV exports. Confirm API/enterprise access with vendor rather than assuming an open API. Maintain metric definition, firmware/device type and activity context per swing.
- References: https://blastmotion.com/rc/ and https://blastmotion.com/faq/

### HitTrax

- HitTrax documents hitting dashboards, session reports, video analysis and competition/game capabilities.
- **Unknown:** a public real-time SDK/API or reliable machine-readable export specification for this use case has **not been verified**.
- **Initial plan:** request approved export/integration documentation. Run BC training games through separate manual scoring UI meanwhile; if vendor permits, use post-session imports with secure player-ID mapping. No screen scraping or unsupported direct access to the device database.
- Reference: https://www.hittrax.com/applications/baseball-softball-training/

### Biomechanics / video

- Use capture-system exports and calibration manifests; store source device, units, frame rate, synchronization offsets, model version and confidence/quality flags.
- Never infer sensor-verified biomechanics from a normal smartphone clip without a validated process.

## Event identity and synchronization

Each measurement needs: `athlete_id`, `organization_id`, `source_system_id`, `device_id` when known, vendor event key, UTC timestamp, training session/context, raw payload pointer, normalized fields and quality flags. Build a player external-ID map that coaches review when ambiguous. Never match athletes on first name alone in production. Linked video should include synchronized clip start/end and camera view.

For a dual sensor record (for example, TrackMan ball metrics and Blast bat metrics), do **not** automatically merge because two timestamps are close; require an explicit session+athlete+time window algorithm, verify sampled pairs, and retain confidence and the original distinct records. Manual match review must be possible.

## Analytics definitions

- `chase_rate = swings at observed out-of-zone pitches / observed out-of-zone pitches`.
- `chase_share = out-of-zone swings / all swings`, a different quantity.
- `zone_whiff = whiffs on in-zone swings / in-zone swings`.
- `mistake_take = takes on athlete-specific defined damage opportunities / such opportunities`.
- `p90_ev = interpolated 90th percentile of eligible exit velocities` (specify algorithm and contextual filters).
- Filters: environment, pitch type, source, collection date, batter side, verified status, contact vs no contact.
- Show `n` and unavailable values. Do not compute a ratio from unknown zone or unknown swing/take input.
- Separate bat-speed metrics from different manufacturers and devices unless a cross-device calibration is demonstrated.
- **Game rules are versioned and cannot be edited retrospectively.**

## Production minimum for university use

1. Security review: FERPA and institutional requirements, retention and privacy policy, consent where applicable.
2. Sign vendor terms and ensure permitted data access and uses.
3. SSO + fine-grained roles + audit trail + encrypted storage + backups + security testing.
4. Approval from coaching leadership/compliance for any data collection/use during games; current NCAA rules and ACC implementation must be verified before deployment.
5. QA harness: data import fixtures, calculations, hard-to-merge player IDs, empty samples, duplicate events, negative tests, and rules-engine unit tests.
6. Offline-first cage input with server-side conflict resolution and idempotent replay.

## Build order

**Phase A:** production authentication + roster + database + data imports + per-hitter profile + planner + coach-scored games.
**Phase B:** TrackMan automated authorized import, Blast team exports, video synchronization, per-player reports, metric quality gates.
**Phase C:** vendor-approved real-time cage feed, live scoreboards, richer biomechanics capture, experiment tracking and advance scouting.
