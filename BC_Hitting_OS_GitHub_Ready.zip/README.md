# BC Hitting OS — Interactive MVP

This is a **working local browser prototype** of the proposed Boston College hitting-department operating system. It is a foundation for product design and workflow testing, **not** a connected university production application.

## Launch

Open `index.html` in Chrome, Edge, Safari, or Firefox. The interface ships with **synthetic demo hitters and synthetic performance measurements**, so you can explore the experience immediately. Every seeded player name begins with `Demo`; none of the statistics should be attributed to an actual BC hitter.

If the file protocol restricts local storage, use a simple local server (Python 3):

```bash
cd bc_hitting_os
python3 -m http.server 8000
```

Then open `http://localhost:8000` in your browser. This serves the prototype only on your machine and does not add authentication or university-grade security.

**Do not import confidential student-athlete, health or university data until BC has approved the application, permissions, storage and retention practices.** Use synthetic or de-identified test data for workflow review.

## What works today

- Command Center: athlete/event counts, synthetic trends, priority list, assignments, integration-readiness overview.
- Player Profiles: add or rename athletes, edit primary/secondary focus, coaching notes, see stats and pitch/event history.
- Training Planner: create, complete and reopen individual assignments.
- Competition Lab: run 6 manually scored game modes; scoring and recent sessions persist to the local browser; export game reps CSV.
- Data Hub: import a canonical `events` CSV with a small alias dictionary; import roster CSV; see row counts; export/restore JSON backups.
- Reports: choose athlete, see a condensed development sheet, print or save PDF, export player event CSV.
- Local persistence: browser `localStorage`, with JSON backup. No cloud, no roster login, no integration secrets.

## What does NOT work yet

- Vendor account integration or real-time TrackMan/Blast/HitTrax ingest.
- Shared, multiuser database, university SSO, authenticated role permissions, audit trail or FERPA-compliant production controls.
- Automatic game scoring from HitTrax / pitch tracking; all game reps are entered by the coach.
- Advanced pitch-level strike-zone mapping, synchronized video, full intervention research, validated predictive analytics.
- Automatic deduplication and sophisticated import mapping for arbitrary proprietary vendor files. The prototype's basic imports are meant for already standardized CSVs. Production will require stronger identity, context and data-quality checks.

## Data import

- Use **Data Hub → Download template** and format rows using the headings below, in imperial units.
- Select the source provenance label. Import and review the preview confirmation. To replace the synthetic profiles entirely, first select **Data Hub → Start with empty workspace** (export a JSON backup before clearing).
- If a new player name appears, the local app creates a new roster record. Production will require verified vendor IDs before accepting that match.

Event CSV fields:

`date,player,source,context,pitch_type,pitch_velo,pitch_zone,decision,contact,exit_velo,launch_angle,bat_speed,attack_angle,carry_ft`

- `date`: `YYYY-MM-DD`.
- `pitch_zone`: `damage`, `strike`, `ball`, or unknown. Do not invent zone location if unavailable.
- `decision`: `swing`, `take`, or unknown.
- `contact`: `true` / `false` / blank.
- Numeric fields: velocity mph, launch/attack angle degrees, carry feet. Blank is acceptable and renders as unavailable.
- Source label is assigned through the import form. Do not represent manually entered readings as verified vendor data.

You can also use `sample_data/events_template.csv` and `sample_data/roster_template.csv`.

## Scoring games

1. Decision Training: adapted from the existing BC 5-round × 12-pitch decision game. Chase −1, taken damage pitch −1, good take +1, hard contact +2, EV at/above chosen threshold +5. Points can accumulate.
2. 3 Less Than 2: coach marks whether the run scored, including sac fly, RBI groundout or hit. Score is manually adjudicated, **not** inferred from exit velocity alone.
3. Damage Before 2K: rewards attack-zone contact before two strikes and punishes chase or unproductive takes. Coach must only log reps with fewer than two strikes.
4. Two-Strike Survival: hard contact, competitive contact, good takes, fouls and avoiding strikeouts.
5. 5,000-Foot Challenge: subtract measured fair-ball carry from 5,000 feet. This uses carry distance, not estimated flight from EV alone.
6. Adjustability Ladder: contact/decisions against varied pitches and locations.

All game rules are **prototype rules and suggested coaching defaults**, not scientifically validated or official team KPI definitions. Keep the test protocol consistent when comparing scores across hitters.

## Technical deliverables

- `schema.sql`: deployable PostgreSQL schema proposal, including organization/roles, athletes, vendor IDs, event sources, session and metric provenance, video, plans, games, imports and audit logs.
- `API_AND_INTEGRATIONS.md`: backend endpoints, API objects, vendor-specific due diligence, synchronization, metric definitions, security and deployment phases.
- `assets/app.js`: inspectable frontend state and scoring logic (future scoring engine should move to the server).
- `assets/styles.css`: responsive visual design.

## Recommended first deployment

Replace synthetic data with verified BC datasets, choose permanent athlete IDs, and connect existing CSV exports **before** implementing machine or vendor automation. Once workflows and metrics are accepted by the hitting staff, implement backend SSO, a shared database, production event ingestion and permissioned video storage.

## Sources for technical due diligence (checked October 2026)

- TrackMan Data API: https://support.trackmanbaseball.com/hc/en-us/articles/5089419125403-Data-Data-API-Introduction
- TrackMan B1 live feed: https://support.trackmanbaseball.com/hc/en-us/articles/5089771759003-B1-App-Trackman-Data-Feeds-Live-Play-by-Play
- Blast team exports: https://blastmotion.com/rc/
- HitTrax documented product features: https://www.hittrax.com/applications/baseball-softball-training/
- NCAA baseball rules portal: https://www.ncaa.org/championships/playing-rules/baseball-playing-rules/
- NCAA performance technology guidance: https://www.ncaa.org/what-we-do/health-safety-and-performance/performance-technologies-guidelines/
